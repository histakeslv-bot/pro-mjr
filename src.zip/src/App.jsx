// src/App.jsx
import React, { useState, useEffect } from 'react';
import './App.css';
import { loadState, saveState } from './storage';
import AuthScreen from './screens/AuthScreen';
import ProjectListScreen from './screens/ProjectListScreen';
import ProjectDetailScreen from './screens/ProjectDetailScreen';
import CheckpointDetailScreen from './screens/CheckpointDetailScreen';
import ProjectExportScreen from './screens/ProjectExportScreen';

const SCREENS = {
  AUTH: 'AUTH',
  PROJECT_LIST: 'PROJECT_LIST',
  PROJECT_DETAIL: 'PROJECT_DETAIL',
  CHECKPOINT_DETAIL: 'CHECKPOINT_DETAIL',
  PROJECT_EXPORT: 'PROJECT_EXPORT',
};

function App() {
  const [state, setState] = useState(() => loadState());
  const [currentScreen, setCurrentScreen] = useState('AUTH');
  const [selectedProjectId, setSelectedProjectId] = useState(null);
  const [selectedCheckpointId, setSelectedCheckpointId] = useState(null);
  const [exportProjectId, setExportProjectId] = useState(null);

  useEffect(() => {
    saveState(state);
  }, [state]);

  const updateUser = (user) => {
    setState((prev) => ({ ...prev, user }));
  };

  const updateProjects = (projects) => {
    setState((prev) => ({ ...prev, projects }));
  };

  const updateCheckpoints = (checkpoints) => {
    setState((prev) => ({ ...prev, checkpoints }));
  };

  const handleLoggedIn = () => {
    setCurrentScreen(SCREENS.PROJECT_LIST);
  };

  const handleProjectSelected = (projectId) => {
    setSelectedProjectId(projectId);
    setCurrentScreen(SCREENS.PROJECT_DETAIL);
  };

  const handleCheckpointSelected = (checkpointId) => {
    setSelectedCheckpointId(checkpointId);
    setCurrentScreen(SCREENS.CHECKPOINT_DETAIL);
  };

  const handleViewExport = (projectId) => {
    setExportProjectId(projectId);
    setCurrentScreen(SCREENS.PROJECT_EXPORT);
  };

  // If user is missing, force auth screen
  if (!state.user && currentScreen !== SCREENS.AUTH) {
    setCurrentScreen(SCREENS.AUTH);
  }

  const selectedProject =
    state.projects.find((p) => p.id === selectedProjectId) || null;

  const projectCheckpoints = state.checkpoints.filter(
    (c) => c.projectId === selectedProjectId
  );

  const selectedCheckpoint =
    state.checkpoints.find((c) => c.id === selectedCheckpointId) || null;

  const exportProject =
    state.projects.find((p) => p.id === exportProjectId) || null;

  const exportCheckpoints = state.checkpoints.filter(
    (c) => c.projectId === exportProjectId
  );

  let content = null;

  switch (currentScreen) {
    case SCREENS.AUTH:
      content = (
        <AuthScreen
          user={state.user}
          onUserChange={updateUser}
          onLoggedIn={handleLoggedIn}
        />
      );
      break;

    case SCREENS.PROJECT_LIST:
      content = (
        <ProjectListScreen
          user={state.user}
          projects={state.projects}
          checkpoints={state.checkpoints}
          onProjectsChange={updateProjects}
          onProjectSelected={handleProjectSelected}
        />
      );
      break;

    case SCREENS.PROJECT_DETAIL:
      content = (
        <ProjectDetailScreen
          project={selectedProject}
          projects={state.projects}
          checkpoints={projectCheckpoints}
          allCheckpoints={state.checkpoints}
          onProjectsChange={updateProjects}
          onCheckpointsChange={updateCheckpoints}
          onBack={() => setCurrentScreen(SCREENS.PROJECT_LIST)}
          onCheckpointSelected={handleCheckpointSelected}
          onViewExport={handleViewExport}
        />
      );
      break;

    case SCREENS.CHECKPOINT_DETAIL:
      content = (
        <CheckpointDetailScreen
          checkpoint={selectedCheckpoint}
          allCheckpoints={state.checkpoints}
          onCheckpointsChange={updateCheckpoints}
          onBack={() => setCurrentScreen(SCREENS.PROJECT_DETAIL)}
        />
      );
      break;

    case SCREENS.PROJECT_EXPORT:
      content = (
        <ProjectExportScreen
          project={exportProject}
          checkpoints={exportCheckpoints}
          user={state.user}
          onBack={() => setCurrentScreen(SCREENS.PROJECT_DETAIL)}
        />
      );
      break;

    default:
      content = <div>Unknown screen</div>;
  }

  return (
    <div className="app-root">
      {content}
    </div>
  );
}

export default App;
