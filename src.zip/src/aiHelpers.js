// src/aiHelpers.js

// -------- Deterministic notes summarizer --------
export function summarizeNotes(notesArray) {
  if (!notesArray || notesArray.length === 0) return '';

  // normalize text
  const cleaned = notesArray
    .map(n => (n || '').trim())
    .filter(n => n.length > 0);

  if (cleaned.length === 0) return '';

  // simple deterministic rules:
  // 1) keep first sentences
  // 2) limit length
  // 3) join with semicolons
  const firstLines = cleaned.map(text => {
    // split on ., !, ? or newline
    const first = text.split(/[\.\?\!\n]/)[0];
    return first.slice(0, 120); // hard cap to prevent huge output
  });

  // remove duplicates
  const unique = [...new Set(firstLines)].slice(0, 5); // cap to 5 items

  return unique.join('; ') + '.';
}


// Simple offline "AI-ish" helpers using rules and basic logic.

function contains(text, word) {
  return text.toLowerCase().includes(word.toLowerCase());
}

// Suggest checkpoints based on project title + goal
export function suggestCheckpointsFromProject(title, goal) {
  const text = `${title} ${goal}`.toLowerCase();
  const suggestions = [];

  // Generic baseline tasks
  suggestions.push('Define success metrics for this project');
  suggestions.push('Break down the project into key milestones');

  if (contains(text, 'app') || contains(text, 'android') || contains(text, 'react')) {
    suggestions.push('List all required features and screens');
    suggestions.push('Implement core functionality');
    suggestions.push('Test the app end-to-end');
    suggestions.push('Prepare release build and store listing');
  }

  if (contains(text, 'licens') || contains(text, 'acquisition') || contains(text, 'rights')) {
    suggestions.push('Identify target companies and decision-makers');
    suggestions.push('Prepare pitch materials and supporting documents');
    suggestions.push('Send initial outreach to selected contacts');
    suggestions.push('Schedule and conduct follow-up conversations');
    suggestions.push('Review legal and contract considerations');
  }

  if (contains(text, 'real estate') || contains(text, 'referral')) {
    suggestions.push('Clarify ideal client and referral profile');
    suggestions.push('Set up online presence and profiles');
    suggestions.push('Contact existing network for referrals');
    suggestions.push('Create follow-up cadence for warm leads');
  }

  if (contains(text, 'freelance') || contains(text, 'contract') || contains(text, 'developer')) {
    suggestions.push('Define target roles and preferred tech stack');
    suggestions.push('Update portfolio and code samples');
    suggestions.push('Apply to selected roles and platforms');
    suggestions.push('Follow up with promising opportunities');
  }

  // Fallback if very few matched
  if (suggestions.length < 4) {
    suggestions.push('List dependencies or resources needed');
    suggestions.push('Schedule weekly review checkpoint');
    suggestions.push('Review progress and adjust plan');
  }

  const unique = Array.from(new Set(suggestions));

  return unique.map((text, index) => ({
    title: text,
    weekNumber: index + 1,
  }));
}

// ---- Project summary + next action helpers ----

export function getProjectStats(project, checkpoints) {
  const total = checkpoints.length;
  const done = checkpoints.filter((c) => c.status === 'done').length;
  const inProgress = checkpoints.filter((c) => c.status === 'in_progress').length;
  const notStarted = checkpoints.filter((c) => c.status === 'not_started').length;

  const now = new Date();
  const overdue = checkpoints.filter((c) => {
    if (!c.dueDate) return false;
    try {
      const d = new Date(c.dueDate);
      return c.status !== 'done' && d < now;
    } catch {
      return false;
    }
  }).length;

  let nextDeadline = null;
  checkpoints.forEach((c) => {
    if (!c.dueDate) return;
    try {
      const d = new Date(c.dueDate);
      if (c.status === 'done') return;
      if (!nextDeadline || d < nextDeadline) {
        nextDeadline = d;
      }
    } catch {
      // ignore invalid dates
    }
  });

  return {
    total,
    done,
    inProgress,
    notStarted,
    overdue,
    nextDeadline,
  };
}

export function getProjectSummaryText(project, checkpoints) {
  const stats = getProjectStats(project, checkpoints);

  if (!stats.total) {
    return 'This project has no checkpoints yet. Start by defining 3–6 key steps.';
  }

  const parts = [];

  parts.push(
    `This project has ${stats.total} checkpoint${stats.total === 1 ? '' : 's'}.`
  );

  parts.push(
    `${stats.done} done, ${stats.inProgress} in progress, ${stats.notStarted} not started.`
  );

  if (stats.overdue > 0) {
    parts.push(
      `${stats.overdue} checkpoint${stats.overdue === 1 ? ' is' : 's are'} overdue.`
    );
  } else {
    parts.push('No checkpoints are currently overdue.');
  }

  if (stats.nextDeadline) {
    parts.push(
      `The next upcoming deadline is ${stats.nextDeadline.toLocaleDateString()}.`
    );
  }

  return parts.join(' ');
}

export function getNextActionSuggestion(project, checkpoints) {
  if (!checkpoints.length) {
    return 'Add your first 3–6 checkpoints to give this project a clear path forward.';
  }

  const remaining = checkpoints.filter((c) => c.status !== 'done');

  if (!remaining.length) {
    return 'All checkpoints are completed. Review the project and consider marking it finished.';
  }

  const sorted = [...remaining].sort((a, b) => {
    if (a.status !== b.status) {
      if (a.status === 'in_progress') return -1;
      if (b.status === 'in_progress') return 1;
    }
    if (!a.dueDate && !b.dueDate) return 0;
    if (!a.dueDate) return 1;
    if (!b.dueDate) return -1;
    return a.dueDate.localeCompare(b.dueDate);
  });

  const next = sorted[0];
  const base = `Next suggested focus: "${next.title || 'Unnamed checkpoint'}".`;

  if (next.dueDate) {
    return `${base} Due on ${new Date(next.dueDate).toLocaleDateString()}.`;
  }
  return base;
}
