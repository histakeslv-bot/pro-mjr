// src/components/SignaturePad.jsx
import React, { useRef, useState, useEffect } from 'react';

const SignaturePad = ({ value, onChange }) => {
  const canvasRef = useRef(null);
  const [isDrawing, setIsDrawing] = useState(false);

  const getCanvasAndContext = () => {
    const canvas = canvasRef.current;
    if (!canvas) return {};
    const ctx = canvas.getContext('2d');
    return { canvas, ctx };
  };

  const getPointFromEvent = (event) => {
    const { canvas } = getCanvasAndContext();
    if (!canvas) return { x: 0, y: 0 };

    const rect = canvas.getBoundingClientRect();
    return {
      x: event.clientX - rect.left,
      y: event.clientY - rect.top,
    };
  };

  const startDrawing = (event) => {
    event.preventDefault();
    const { ctx } = getCanvasAndContext();
    if (!ctx) return;

    const point = getPointFromEvent(event);
    ctx.beginPath();
    ctx.moveTo(point.x, point.y);
    setIsDrawing(true);

    try {
      event.target.setPointerCapture(event.pointerId);
    } catch {
      // ignore unsupported
    }
  };

  const draw = (event) => {
    if (!isDrawing) return;
    event.preventDefault();

    const { ctx, canvas } = getCanvasAndContext();
    if (!ctx || !canvas) return;

    const point = getPointFromEvent(event);
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';
    ctx.lineTo(point.x, point.y);
    ctx.stroke();
  };

  const endDrawing = (event) => {
    if (!isDrawing) return;
    event.preventDefault();
    setIsDrawing(false);

    const { canvas } = getCanvasAndContext();
    if (!canvas) return;

    try {
      event.target.releasePointerCapture(event.pointerId);
    } catch {
      // ignore unsupported
    }

    const dataUrl = canvas.toDataURL('image/png');
    onChange?.(dataUrl);
  };

  const handleClear = () => {
    const { canvas, ctx } = getCanvasAndContext();
    if (!canvas || !ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    onChange?.(null);
  };

  // redraw saved signature when opening
  useEffect(() => {
    const { canvas, ctx } = getCanvasAndContext();
    if (!canvas || !ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    if (value) {
      const img = new Image();
      img.onload = () => {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      };
      img.src = value;
    }
  }, [value]);

  return (
    <div className="signature-pad">
      <canvas
        ref={canvasRef}
        width={400}
        height={200}
        className="signature-canvas"
        onPointerDown={startDrawing}
        onPointerMove={draw}
        onPointerUp={endDrawing}
        onPointerLeave={endDrawing}
      />
      <button type="button" onClick={handleClear}>
        Clear
      </button>
    </div>
  );
};

export default SignaturePad;
