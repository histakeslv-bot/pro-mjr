// src/screens/AuthScreen.jsx
import React, { useState } from 'react';

function hash(password) {
  // extremely simple placeholder hash – local/offline only
  return `hash_${password}`;
}

const AuthScreen = ({ user, onUserChange, onLoggedIn }) => {
  const [mode, setMode] = useState('login'); // 'login' | 'create'
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');

    // ---------------------------
    // HARD-CODED DEV ADMIN LOGIN
    // ---------------------------
    if (
      firstName.trim().toLowerCase() === 'admin' &&
      lastName.trim().toLowerCase() === 'admin' &&
      password === 'admin123'
    ) {
      onUserChange({
        firstName: 'Admin',
        lastName: 'User',
        passwordHash: hash('admin123'),
        createdAt: new Date().toISOString(),
      });

      onLoggedIn();
      return;
    }

    // --------------------------------
    // NORMAL account create / login
    // --------------------------------
    if (mode === 'create') {
      if (!firstName || !lastName || !password) {
        setError('All fields are required.');
        return;
      }

      const newUser = {
        firstName,
        lastName,
        passwordHash: hash(password),
        createdAt: new Date().toISOString(),
      };

      onUserChange(newUser);
      onLoggedIn();
      return;
    }

    // LOGIN MODE
    if (!user) {
      setError('No account exists yet. Create one first.');
      return;
    }

    if (
      user.firstName.toLowerCase() === firstName.trim().toLowerCase() &&
      user.lastName.toLowerCase() === lastName.trim().toLowerCase() &&
      user.passwordHash === hash(password)
    ) {
      onLoggedIn();
    } else {
      setError('Invalid name or password.');
    }
  };

  return (
    <div className="auth-screen">
      <h1>Pro Mjr</h1>
      <p>Offline Project Manager</p>

      <div className="mode-switch">
        <button
          onClick={() => setMode('login')}
          disabled={mode === 'login'}
        >
          Log in
        </button>
        <button
          onClick={() => setMode('create')}
          disabled={mode === 'create'}
        >
          Create account
        </button>
      </div>

      <form onSubmit={handleSubmit}>
        <label>
          First name
          <input
            value={firstName}
            onChange={(e) => setFirstName(e.target.value)}
          />
        </label>

        <label>
          Last name
          <input
            value={lastName}
            onChange={(e) => setLastName(e.target.value)}
          />
        </label>

        <label>
          Password
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </label>

        {error && <p className="error">{error}</p>}

        <button type="submit">
          {mode === 'login' ? 'Log in' : 'Create account'}
        </button>

        <p style={{ fontSize: '0.8rem', marginTop: '8px' }}>
          Dev login: admin / admin / admin123
        </p>
      </form>
    </div>
  );
};

export default AuthScreen;
