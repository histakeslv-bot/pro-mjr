// src/screens/CheckpointDetailScreen.jsx
import React, { useEffect, useState } from 'react';

const CheckpointDetailScreen = ({
  checkpoint,
  allCheckpoints,
  onCheckpointsChange,
  onBack,
}) => {
  const [title, setTitle] = useState('');
  const [weekNumber, setWeekNumber] = useState(1);
  const [dueDate, setDueDate] = useState('');
  const [status, setStatus] = useState('not_started');
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (checkpoint) {
      setTitle(checkpoint.title || '');
      setWeekNumber(checkpoint.weekNumber || 1);
      setDueDate(checkpoint.dueDate || '');
      setStatus(checkpoint.status || 'not_started');
      setNotes(checkpoint.notes || '');
    }
  }, [checkpoint]);

  if (!checkpoint) {
    return (
      <div className="checkpoint-detail-screen">
        <button onClick={onBack}>← Back to project</button>
        <p>Checkpoint not found.</p>
      </div>
    );
  }

  const handleSave = () => {
    const updated = {
      ...checkpoint,
      title: title.trim() || 'Untitled checkpoint',
      weekNumber: Number(weekNumber) || 1,
      dueDate: dueDate || '',
      status,
      notes,
    };

    const updatedAll = allCheckpoints.map((c) =>
      c.id === checkpoint.id ? updated : c
    );

    onCheckpointsChange(updatedAll);
    onBack();
  };

  const handleDelete = () => {
    const confirmed = window.confirm('Delete this checkpoint?');
    if (!confirmed) return;

    const updatedAll = allCheckpoints.filter((c) => c.id !== checkpoint.id);
    onCheckpointsChange(updatedAll);
    onBack();
  };

  return (
    <div className="checkpoint-detail-screen">
      <button onClick={onBack}>← Back to project</button>
      <h1>Edit checkpoint</h1>

      <label>
        Title
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
      </label>

      <label>
        Week number
        <input
          type="number"
          min="1"
          value={weekNumber}
          onChange={(e) => setWeekNumber(e.target.value)}
        />
      </label>

      <label>
        Due date
        <input
          type="date"
          value={dueDate}
          onChange={(e) => setDueDate(e.target.value)}
        />
      </label>

      <label>
        Status
        <select
          value={status}
          onChange={(e) => setStatus(e.target.value)}
        >
          <option value="not_started">Not started</option>
          <option value="in_progress">In progress</option>
          <option value="done">Done</option>
        </select>
      </label>

      <label>
        Notes
        <textarea
          rows={5}
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
        />
      </label>

      <div className="form-actions">
        <button onClick={handleSave}>Save</button>
        <button onClick={handleDelete}>Delete checkpoint</button>
      </div>
    </div>
  );
};

export default CheckpointDetailScreen;
