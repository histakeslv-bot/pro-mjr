// src/screens/ProjectDetailScreen.jsx
import React, { useState } from 'react';
import { summarizeNotes } from '../aiHelpers';
import SignaturePad from '../components/SignaturePad';
import {
  suggestCheckpointsFromProject,
  getProjectSummaryText,
  getNextActionSuggestion,
} from '../aiHelpers';

function createId() {
  return Math.random().toString(36).slice(2);
}

const ProjectDetailScreen = ({
  project,
  projects,
  checkpoints,
  allCheckpoints,
  onProjectsChange,
  onCheckpointsChange,
  onBack,
  onCheckpointSelected,
  onViewExport,
}) => {
  const [showCompleteModal, setShowCompleteModal] = useState(false);
  const [signatureData, setSignatureData] = useState(
    project?.completionSignature || null
  );
  const [completeError, setCompleteError] = useState('');

  if (!project) {
    return (
      <div className="project-detail-screen">
        <button onClick={onBack}>← Back to projects</button>
        <p>Project not found.</p>
      </div>
    );
  }

  const projectCheckpoints = checkpoints || [];

  const summaryText = getProjectSummaryText(project, projectCheckpoints);
  const nextActionText = getNextActionSuggestion(project, projectCheckpoints);

  const handleAddCheckpoint = () => {
    const newCheckpoint = {
      id: createId(),
      projectId: project.id,
      title: 'New checkpoint',
      weekNumber: 1,
      status: 'not_started',
      notes: '',
      dueDate: '',
    };

    const updatedAll = [...allCheckpoints, newCheckpoint];
    onCheckpointsChange(updatedAll);
    onCheckpointSelected(newCheckpoint.id);
  };

  const handleSuggestCheckpoints = () => {
    const existing = projectCheckpoints.map((c) =>
      (c.title || '').trim().toLowerCase()
    );
    const suggestions = suggestCheckpointsFromProject(
      project.title,
      project.goal
    );

    const newOnes = suggestions.filter(
      (s) => !existing.includes(s.title.toLowerCase())
    );

    if (!newOnes.length) {
      window.alert('No new suggestions. You already have similar checkpoints.');
      return;
    }

    const created = newOnes.map((s) => ({
      id: createId(),
      projectId: project.id,
      title: s.title,
      weekNumber: s.weekNumber,
      status: 'not_started',
      notes: '',
      dueDate: '',
    }));

    const updatedAll = [...allCheckpoints, ...created];
    onCheckpointsChange(updatedAll);
  };

  const handleUpdateProjectStatus = (updatedFields) => {
    const updatedProject = { ...project, ...updatedFields };
    const updatedProjects = projects.map((p) =>
      p.id === project.id ? updatedProject : p
    );
    onProjectsChange(updatedProjects);
  };

  const handleMarkCompleteClicked = () => {
    setCompleteError('');
    setShowCompleteModal(true);
  };

  const handleConfirmComplete = () => {
    if (!signatureData) {
      setCompleteError('Please sign before completing the project.');
      return;
    }

    const now = new Date().toISOString();
    handleUpdateProjectStatus({
      status: 'completed',
      completedAt: now,
      completionSignature: signatureData,
    });
    setShowCompleteModal(false);
  };

  const getStatusLabel = (status) => {
    if (status === 'completed') return 'Completed';
    return 'Active';
  };

  const getCheckpointStatusLabel = (status) => {
    switch (status) {
      case 'in_progress':
        return 'In progress';
      case 'done':
        return 'Done';
      default:
        return 'Not started';
    }
  };

  const getProgressText = () => {
    if (!projectCheckpoints.length) return 'No checkpoints yet';
    const done = projectCheckpoints.filter((c) => c.status === 'done').length;
    return `${done} of ${projectCheckpoints.length} checkpoints done`;
  };

  return (
    <div className="project-detail-screen">
      <button onClick={onBack}>← Back to projects</button>

      <header className="project-header">
        <h1>{project.title}</h1>
        <p className="status">Status: {getStatusLabel(project.status)}</p>
        <p className="created-at">
          Created: {new Date(project.createdAt).toLocaleString()}
        </p>
        {project.status === 'completed' && project.completedAt && (
          <p className="completed-at">
            Completed: {new Date(project.completedAt).toLocaleString()}
          </p>
        )}
      </header>

      <section className="project-goal">
        <h2>Overall goal</h2>
        <p>{project.goal}</p>
      </section>

      <section className="project-progress">
        <h2>Checkpoints</h2>

        <p className="progress-summary">{getProgressText()}</p>
        <p className="ai-summary">{summaryText}</p>
        <p className="ai-next-action">{nextActionText}</p>

        <div className="checkpoint-actions">
          <button type="button" onClick={handleAddCheckpoint}>
            + Add checkpoint
          </button>
          <button type="button" onClick={handleSuggestCheckpoints}>
            Suggest checkpoints
          </button>
        </div>

        {!projectCheckpoints.length && (
          <p>No checkpoints yet. You can add your own or use suggestions.</p>
        )}

        <div className="checkpoint-list">
          {projectCheckpoints.map((cp) => (
            <div
              key={cp.id}
              className="checkpoint-row"
              onClick={() => onCheckpointSelected(cp.id)}
            >
              <div className="checkpoint-main">
                <h3>{cp.title || 'Untitled checkpoint'}</h3>
                <p>
                  Week {cp.weekNumber || 1}{' '}
                  {cp.dueDate &&
                    `• Due ${new Date(cp.dueDate).toLocaleDateString()}`}
                </p>
        <p className="checkpoint-notes-summary">
          {summarizeNotes([cp.notes])}
        </p>           
   </div>
              <div className="checkpoint-meta">
                <span className={`checkpoint-status status-${cp.status}`}>
                  {getCheckpointStatusLabel(cp.status)}
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="project-completion">
        <h2>Completion</h2>
        {project.status !== 'completed' ? (
          <>
            <p>
              When this project is fully done, mark it complete and sign to
              generate a completion record.
            </p>
            <button onClick={handleMarkCompleteClicked}>
              Mark project complete
            </button>
          </>
        ) : (
          <>
            <p>This project is completed.</p>
            {project.completionSignature && (
              <div className="signature-preview">
                <p>Signed completion record:</p>
                <img
                  src={project.completionSignature}
                  alt="Completion signature"
                  className="signature-image"
                />
              </div>
            )}
            <button
              type="button"
              onClick={() => onViewExport && onViewExport(project.id)}
            >
              View export summary
            </button>
          </>
        )}
      </section>

      {showCompleteModal && (
        <div className="modal-overlay">
          <div className="modal">
            <h2>Complete project</h2>
            <p>
              Project: <strong>{project.title}</strong>
            </p>
            <p>
              Completion time (device):{' '}
              <strong>{new Date().toLocaleString()}</strong>
            </p>

            <p>Sign below to confirm completion:</p>
            <SignaturePad value={signatureData} onChange={setSignatureData} />

            {completeError && <p className="error">{completeError}</p>}

            <div className="modal-actions">
              <button onClick={handleConfirmComplete}>
                Confirm completion
              </button>
              <button
                onClick={() => {
                  setShowCompleteModal(false);
                  setCompleteError('');
                }}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProjectDetailScreen;
