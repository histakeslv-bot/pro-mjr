// src/screens/ProjectExportScreen.jsx
import React from 'react';
import { getProjectSummaryText } from '../aiHelpers';
import { summarizeNotes } from '../aiHelpers';

const ProjectExportScreen = ({ project, checkpoints, user, onBack }) => {
  if (!project) {
    return (
      <div className="export-page">
        <div className="export-toolbar no-print">
          <button onClick={onBack}>← Back</button>
        </div>
        <p>Project not found.</p>
      </div>
    );
  }

  const sortedCheckpoints = [...checkpoints].sort((a, b) => {
    if (a.weekNumber !== b.weekNumber) {
      return a.weekNumber - b.weekNumber;
    }
    if (!a.dueDate && !b.dueDate) return 0;
    if (!a.dueDate) return 1;
    if (!b.dueDate) return -1;
    return a.dueDate.localeCompare(b.dueDate);
  });

  const formatDateTime = (value) => {
    if (!value) return '-';
    try {
      return new Date(value).toLocaleString();
    } catch {
      return value;
    }
  };

  const formatDateOnly = (value) => {
    if (!value) return '-';
    try {
      return new Date(value).toLocaleDateString();
    } catch {
      return value;
    }
  };

  const statusLabel = project.status === 'completed' ? 'Completed' : 'Active';
  const summaryText = getProjectSummaryText(project, sortedCheckpoints);

  return (
    <div className="export-page">
      {/* Toolbar shown only on screen, hidden when printing */}
      <div className="export-toolbar no-print">
        <button onClick={onBack}>← Back to project</button>
        <button type="button" onClick={() => window.print()}>
          Print / Save as PDF
        </button>
      </div>

      <div className="export-view">
        <header className="export-header">
          <h1>Project Completion Summary</h1>
          <p className="export-meta">
            {user && (
              <>
                Owner:{' '}
                <strong>
                  {user.firstName} {user.lastName}
                </strong>
                <br />
              </>
            )}
            Generated:{' '}
            <strong>{new Date().toLocaleString()}</strong>
          </p>
        </header>

        <section className="export-section">
          <h2>Project details</h2>
          <p>
            <strong>Title:</strong> {project.title}
          </p>
          <p>
            <strong>Status:</strong> {statusLabel}
          </p>
          <p>
            <strong>Created:</strong> {formatDateTime(project.createdAt)}
          </p>
          <p>
            <strong>Completed:</strong>{' '}
            {project.completedAt
              ? formatDateTime(project.completedAt)
              : 'Not completed'}
          </p>
        </section>

        <section className="export-section">
          <h2>Overall goal</h2>
          <p className="export-goal">{project.goal}</p>
        </section>

        <section className="export-section">
          <h2>Summary</h2>
          <p>{summaryText}</p>
        </section>

        <section className="export-section">
          <h2>Checkpoints</h2>
          {sortedCheckpoints.length === 0 ? (
            <p>No checkpoints recorded for this project.</p>
          ) : (
            <table className="export-table">
              <thead>
                <tr>
                  <th>Week</th>
                  <th>Title</th>
                  <th>Due date</th>
                  <th>Status</th>
                  <th>Notes</th>
                </tr>
              </thead>
              <tbody>
                {sortedCheckpoints.map((cp) => (
                  <tr key={cp.id}>
                    <td>{cp.weekNumber || '-'}</td>
<td>
  <div>{cp.title || 'Untitled checkpoint'}</div>
  <div style={{ fontSize: '0.8rem' }}>
    {summarizeNotes([cp.notes])}
  </div>
</td>
                    <td>{formatDateOnly(cp.dueDate)}</td>
                    <td>
                      {cp.status === 'done'
                        ? 'Done'
                        : cp.status === 'in_progress'
                        ? 'In progress'
                        : 'Not started'}
                    </td>
                    <td className="notes-cell">
                      {cp.notes ? cp.notes : '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>

        <section className="export-section">
          <h2>Signature</h2>
          {project.completionSignature ? (
            <div className="export-signature-block">
              <p>
                Signed by{' '}
                {user
                  ? `${user.firstName} ${user.lastName}`
                  : '__________'}
              </p>
              <div className="export-signature-box">
                <img
                  src={project.completionSignature}
                  alt="Completion signature"
                />
              </div>
              {project.completedAt && (
                <p className="export-signature-time">
                  Signed at: {formatDateTime(project.completedAt)}
                </p>
              )}
            </div>
          ) : (
            <p>No completion signature captured yet.</p>
          )}
        </section>
      </div>
    </div>
  );
};

export default ProjectExportScreen;
