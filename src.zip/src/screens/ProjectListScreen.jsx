// src/screens/ProjectListScreen.jsx
import React, { useState } from 'react';

function createId() {
  return Math.random().toString(36).slice(2);
}

const ProjectListScreen = ({
  user,
  projects,
  checkpoints,
  onProjectsChange,
  onProjectSelected,
}) => {
  const [showNewForm, setShowNewForm] = useState(false);
  const [title, setTitle] = useState('');
  const [goal, setGoal] = useState('');
  const maxProjects = 4;
  const canCreateMore = projects.length < maxProjects;

  const handleCreateProject = () => {
    if (!title || !goal) return;

    const newProject = {
      id: createId(),
      title,
      goal,
      status: 'active',
      createdAt: new Date().toISOString(),
    };

    onProjectsChange([...projects, newProject]);
    setTitle('');
    setGoal('');
    setShowNewForm(false);
  };

  const getProgressText = (projectId) => {
    const cps = checkpoints.filter((c) => c.projectId === projectId);
    if (!cps.length) return 'No checkpoints yet';
    const done = cps.filter((c) => c.status === 'done').length;
    return `${done} of ${cps.length} checkpoints done`;
  };

  return (
    <div className="project-list-screen">
      <h1>Pro Mjr</h1>
      {user && (
        <p className="greeting">
          Logged in as {user.firstName} {user.lastName}
        </p>
      )}

      <div className="project-list-header">
        <h2>Your projects</h2>
        {canCreateMore && (
          <button onClick={() => setShowNewForm(true)}>
            New project
          </button>
        )}
      </div>

      {!projects.length && (
        <p>No projects yet. Create your first one to get started.</p>
      )}

      <div className="project-list">
        {projects.map((project) => (
          <div
            key={project.id}
            className="project-card"
            onClick={() => onProjectSelected(project.id)}
          >
            <h3>{project.title}</h3>
            <p className="goal-snippet">
              {project.goal.length > 80
                ? project.goal.slice(0, 80) + '…'
                : project.goal}
            </p>
            <p className="status">
              Status:{' '}
              {project.status === 'completed' ? 'Completed' : 'Active'}
            </p>
            <p className="progress">{getProgressText(project.id)}</p>
          </div>
        ))}
      </div>

      {showNewForm && (
        <div className="new-project-form">
          <h3>New project</h3>
          <label>
            Title
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </label>
          <label>
            Overall goal
            <textarea
              value={goal}
              onChange={(e) => setGoal(e.target.value)}
            />
          </label>
          <div className="form-actions">
            <button type="button" onClick={handleCreateProject}>
              Create
            </button>
            <button
              type="button"
              onClick={() => setShowNewForm(false)}
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {!canCreateMore && (
        <p className="limit-info">
          You’ve reached the max of {maxProjects} projects for this version.
        </p>
      )}
    </div>
  );
};

export default ProjectListScreen;
