// src/storage.js

const STORAGE_KEY = 'proMjrState';

const defaultState = {
  user: null,
  projects: [],
  checkpoints: [],
};

export function loadState() {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultState;

    const parsed = JSON.parse(raw);

    return {
      user: parsed.user ?? null,
      projects: Array.isArray(parsed.projects) ? parsed.projects : [],
      checkpoints: Array.isArray(parsed.checkpoints) ? parsed.checkpoints : [],
    };
  } catch (err) {
    console.error('Failed to load state:', err);
    return defaultState;
  }
}

export function saveState(state) {
  try {
// --- signature invalidation rule ---
// if a completed/signed project is modified, invalidate the signature
try {
  const prev = loadState();

  state.projects = state.projects.map(p => {
    const old = prev.projects.find(op => op.id === p.id);

    // if there was no previous project, nothing to compare
    if (!old) return p;

    const wasCompleted = !!old.completedAt && !!old.completionSignature;
    const changed = JSON.stringify(old) !== JSON.stringify(p);

    if (wasCompleted && changed) {
      return {
        ...p,
	completionSignature: null,
        completedAt: null,
        status: 'In progress'
      };
    }

    return p;
  });
} catch (e) {
  console.warn('Signature invalidation check failed:', e);
}
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (err) {
    console.error('Failed to save state:', err);
  }
}
